const sql = require('mssql');
const https = require('https');
const fs = require('fs');
const path = require('path');

const SQL_CONFIG = {
  server: 'CPSERVER',
  database: 'etimetracklite1',
  user: 'essl',
  password: 'essl',
  options: {
    encrypt: false,
    trustServerCertificate: true,
    enableArithAbort: true,
  },
  port: 1433,
};

const HR_API_URL    = 'https://eod.colorpapers.in';
const HR_AGENT_KEY  = 'cpipl-bio-sync-2026-xK9mP4qR7v2';
const DEVICE_SERIAL = 'CUB7240300491';
const LOOKBACK_DAYS = 1;
const LOG_FILE      = path.join(__dirname, 'sync-log.txt');

function log(msg) {
  const line = `[${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}] ${msg}`;
  console.log(line);
  try { fs.appendFileSync(LOG_FILE, line + '\n'); } catch {}
}

async function fetchPunchesFromSQL() {
  const pool = await sql.connect(SQL_CONFIG);
  const now = new Date();
  const month = now.getMonth() + 1;
  const year = now.getFullYear();
  const tableName = `DeviceLogs_${month}_${year}`;
  const since = new Date();
  since.setDate(since.getDate() - LOOKBACK_DAYS);

  const result = await pool.request()
    .input('since', sql.DateTime, since)
    .query(`
      SELECT
        CAST(UserId AS VARCHAR) AS enrollNumber,
        LogDate                 AS punchTime,
        Direction               AS direction
      FROM dbo.${tableName}
      WHERE LogDate >= @since
      ORDER BY LogDate ASC
    `);

  await pool.close();

  return result.recordset.map(row => ({
    enrollNumber: String(row.enrollNumber),
    punchTime:    formatDateTime(row.punchTime),
    direction:    row.direction ? row.direction.trim().toLowerCase() : null,
  }));
}

function formatDateTime(dt) {
  const d = new Date(dt);
  return d.toISOString().slice(0, 19).replace('T', ' ');
}

async function pushToHR(punches) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({
      agentKey:     HR_AGENT_KEY,
      deviceSerial: DEVICE_SERIAL,
      punches,
    });

    const url = new URL(`${HR_API_URL}/api/biometric/sync`);
    const options = {
      hostname: url.hostname,
      path:     url.pathname,
      method:   'POST',
      headers:  {
        'Content-Type':   'application/json',
        'Content-Length': Buffer.byteLength(body),
        'x-agent-key':    HR_AGENT_KEY,
      },
    };

    const req = https.request(options, res => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch { resolve({ raw: data }); }
      });
    });

    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

// ── Run once and exit (Task Scheduler handles repeating) ──
(async () => {
  log('--- Sync started ---');
  try {
    const punches = await fetchPunchesFromSQL();
    log(`Fetched ${punches.length} punch records from SQL`);
    if (punches.length === 0) {
      log('No punches found. Done.');
      process.exit(0);
    }
    const result = await pushToHR(punches);
    log(`Result: ${JSON.stringify(result)}`);
  } catch (err) {
    log(`ERROR: ${err.message}`);
  }
  process.exit(0);
})();
